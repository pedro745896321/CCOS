export function validarCPF(cpf: string): boolean {
    cpf = cpf.replace(/\D/g, '');

    if (cpf.length !== 11) return false;
    if (/^(\d)\1{10}$/.test(cpf)) return false;

    const calcDigito = (base: string, peso: number) => {
        let soma = 0;
        for (let i = 0; i < base.length; i++) {
            soma += parseInt(base.charAt(i)) * (peso - i);
        }
        let resto = (soma * 10) % 11;
        return (resto === 10 || resto === 11) ? 0 : resto;
    };

    const digito1 = calcDigito(cpf.substring(0, 9), 10);
    const digito2 = calcDigito(cpf.substring(0, 9) + digito1, 11);

    return cpf.endsWith(`${digito1}${digito2}`);
}

export function capitalizarNome(nome: string): string {
    return nome.trim().replace(/\s+/g, ' ').split(" ").map(p => {
        const lower = p.toLowerCase();
        if (['da', 'de', 'do', 'dos', 'das', 'e'].includes(lower)) {
            return lower;
        }
        return p.charAt(0).toUpperCase() + p.slice(1).toLowerCase();
    }).join(" ");
}

export async function resizeImage(fileBlob: Blob, maxWidth = 1200, maxHeight = 1200, quality = 0.8): Promise<Blob | null> {
    return new Promise((resolve) => {
        const img = new Image();
        const reader = new FileReader();

        reader.onload = (e) => {
            img.src = e.target?.result as string;
            img.onload = () => {
                const canvas = document.createElement('canvas');
                let width = img.width;
                let height = img.height;

                if (width > height) {
                    if (width > maxWidth) {
                        height *= maxWidth / width;
                        width = maxWidth;
                    }
                } else {
                    if (height > maxHeight) {
                        width *= maxHeight / height;
                        height = maxHeight;
                    }
                }

                canvas.width = width;
                canvas.height = height;

                const ctx = canvas.getContext('2d');
                if (!ctx) {
                    resolve(null);
                    return;
                }
                ctx.drawImage(img, 0, 0, width, height);

                canvas.toBlob((blob) => {
                    resolve(blob);
                }, 'image/jpeg', quality);
            };
        };
        reader.readAsDataURL(fileBlob);
    });
}
